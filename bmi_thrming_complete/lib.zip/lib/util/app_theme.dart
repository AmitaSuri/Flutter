import 'package:flutter/material.dart';
import './constants.dart';

class AppTheme {
  AppTheme();

  static ThemeData buildBmiTheme() {
    final ThemeData base = ThemeData.light();

    return base.copyWith(
      primaryColor: kPrimaryBlue,
      primaryColorLight: kPrimaryBlueLight,
      primaryColorDark: kPrimaryBlueDark,
      accentColor: kSecondaryPink,

      scaffoldBackgroundColor: kSecondaryBackgroundWhite,

      appBarTheme: AppBarTheme(
        textTheme: base.textTheme.copyWith(
          headline6: TextStyle(
            color: kTextOnPrimaryWhite,
            fontFamily: "SourceSansPro",
            fontSize: 24.0,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      cardTheme: base.cardTheme.copyWith(
        elevation: 1.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
          side: BorderSide(color: kSecondaryPink),
        ),
      ),

      buttonTheme: base.buttonTheme.copyWith(
        buttonColor: kPrimaryBlue,
        padding: EdgeInsets.all(10.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
          side: BorderSide(color: kSecondaryPink),
        ),
      ),

      inputDecorationTheme: base.inputDecorationTheme.copyWith(
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: kPrimaryBlueDark,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        hintStyle: TextStyle(
          fontSize: 16.0,
          fontFamily: "SourceSansPro",
          color: kTextOnSecondaryBlack,
        ),
      ),

      iconTheme: base.iconTheme.copyWith(
        color: kTextOnSecondaryBlack,
        size: 26.0,
      ),

      textTheme: _buildBmiTextTheme(base.textTheme),
    );
  }

  static _buildBmiTextTheme(TextTheme base) {
    return base
        .copyWith(
          headline6: kHeadline6Style,
          bodyText1: kBodyText1Style,
          bodyText2: TextStyle(
            color: kTextOnSecondaryBlack,
            fontSize: 18.0,
            fontWeight: FontWeight.w500,
            fontFamily: 'Pacifico',
          ),
          button: kButtonTextStyle,
        )
        .apply(
            // This will override and apply to both bodyText2 and button
            // fontFamily: 'Pacifico',
            );
  }
}
