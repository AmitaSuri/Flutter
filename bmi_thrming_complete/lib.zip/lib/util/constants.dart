import 'package:flutter/material.dart';

const kPrimaryBlue = const Color(0xff6200ea);
const kPrimaryBlueLight = const Color(0xff9d46ff);
const kPrimaryBlueDark = const Color(0xff0a00b6);

const kSecondaryPink = const Color(0xffec407a); 
const kSecondaryPinkLight = const Color(0xffff77a9); 
const kSecondaryPinkDark = const Color(0xffb4004e); 

const kTextOnPrimaryWhite = const Color(0xffffffff);
const kTextOnSecondaryBlack = const Color(0xff000000);

const kSecondaryBackgroundWhite = const Color(0xffffffff);

const kHeadline6Style = TextStyle(
    color:  kTextOnSecondaryBlack,
    fontSize: 20.0,
    fontWeight: FontWeight.w700,
    fontFamily: "SourceSansPro",
);

const kBodyText1Style = TextStyle(
    color:  kTextOnSecondaryBlack,
    fontSize: 16.0,
    fontWeight: FontWeight.w200,
    fontFamily: 'Pacifico',
);

const kButtonTextStyle = TextStyle(
  fontSize: 20.0,
  fontWeight: FontWeight.w400,
  fontFamily: "SourceSansPro",
);