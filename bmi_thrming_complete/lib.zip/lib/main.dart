import 'package:flutter/material.dart';
import './ui/bmi_app.dart';
import './util/app_theme.dart';

final ThemeData _bmiTheme = AppTheme.buildBmiTheme();

void main() => runApp(
      new MaterialApp(
        theme: _bmiTheme,
        home: BmiApp(),
      ),
);
