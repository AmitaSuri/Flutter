import 'package:flutter/material.dart';
import '../util/constants.dart';

class BmiInputs extends StatelessWidget {
  final double parameterValue;
  final String parameterName;
  final Function onChangedHandler;
  final double min;
  final double max;

  const BmiInputs({
    @required this.min,
    @required this.max,
    @required this.parameterValue, 
    @required this.parameterName, 
    @required this.onChangedHandler
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 5.0),
      child: Column(
         children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
           children: <Widget>[
              Text(
                "$parameterName",
              ), 
              Text("${parameterValue.toStringAsFixed(2)}")
            ],
          ),

          //Slider
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
                      thumbColor: Theme.of(context).primaryColor,
                      thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12.0),
                      overlayShape: RoundSliderOverlayShape(overlayRadius: 20.0),
                      overlayColor:  Theme.of(context).primaryColorLight,
                      activeTrackColor: kSecondaryPink,
                      inactiveTrackColor: kSecondaryPinkLight,
                    ),
                    child: Slider(
              min: min,
              max: max,
              value: parameterValue,
              onChanged: onChangedHandler
             ),
          ),
        ],
      ),
    );
  }
}