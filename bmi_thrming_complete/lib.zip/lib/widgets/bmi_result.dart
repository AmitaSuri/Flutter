import 'package:flutter/material.dart';

class BmiResult extends StatelessWidget {
  final String name;
  final String bmi;
  final String result;
  final String interpretation;

  const BmiResult({
    this.name,
    this.bmi,
    this.result,
    this.interpretation,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150.0,
      child: Card(
        elevation: 5,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text(
                (bmi != '') ? "BMI: $bmi" : "BMI",
                style: Theme.of(context).textTheme.headline6,
              ),
              SizedBox(height: 9),
              Text(
                (name != '' && result != '') ? "$name, you are $result." : '',
                style: Theme.of(context).textTheme.bodyText1,
              ),
              SizedBox(height: 5),
              Text(
                (interpretation != '') ? '$interpretation' : '',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyText1,
              )
            ],
          ),
        ),
      ),
    );
  }
}
