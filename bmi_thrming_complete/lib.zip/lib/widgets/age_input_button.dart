import 'package:flutter/material.dart';

class AgeInputButton extends StatelessWidget {
  final Function onTapHandler;
  final IconData icon;

  AgeInputButton({this.icon, this.onTapHandler});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTapHandler,
      child: Container(
        width: 40,
        height: 40,
        margin: EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Theme.of(context).accentColor,
        ),
        child: Center(
            child: Icon(icon),
        ), 
      ),
    );
  }
}
