import 'package:flutter/material.dart';
import './movie_ui/movie_ui.dart';
import './model/movie.dart';
//import './movie_ui/movie_ui.dart';
//import './util/hexcolor.dart';


void main() {
  runApp(
      new MaterialApp(
        home: MovieListView(),
        //home: new Screen1(),
        // routes: <String, WidgetBuilder> {
        //   '/screen1': (BuildContext context) => new Screen1(),
        //   '/screen2' : (BuildContext context) => new Screen2(),
        //   '/screen3' : (BuildContext context) => new Screen3(),
        //   '/screen4' : (BuildContext context) => new Screen4()
        // },
      )
  );
}

class MovieListView extends StatelessWidget {
  final List<Movie> movieList = Movie.getMovies();

  final List movies = [
    "Titanic",
    "Blade Runner",
    "Rambo",
    "The Avengers",
    "Avatar",
    "I Am Legend",
    "300",
    "The Wolf of Wall Street",
    "Interstellar",
    "Game of Thrones",
    "Vikings",
    "Vikings",
    "Vikings"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Movies"),
        backgroundColor: Colors.blueGrey.shade900,
      ),
      backgroundColor: Colors.blueGrey.shade900,
      body: ListView.builder(
          itemCount: movieList.length,
          itemBuilder: (BuildContext context, int index) {
            return Stack(children: <Widget>[
              movieCard(movieList[index], context),
              Positioned(
                  top: 10.0, child: movieImage(movieList[index].images[0])),
            ]);
             }),
    );
  }

  Widget movieCard(Movie movie, BuildContext context) {
    return InkWell(
      child: Container(
        margin: EdgeInsets.only(left: 60),
        width: MediaQuery.of(context).size.width,
        height: 120.0,
        child: Card(
          color: Colors.black45,
          child: Padding(
            padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, left: 54.0),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Flexible(
                          child: Text(
                            movie.title,
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 17.0,
                                color: Colors.white),
                          ),
                        ),
                        Text(
                          "Rating: ${movie.imdbRating} / 10",
                          style: TextStyle(fontSize: 15.0, color: Colors.grey),
                        )
                      ]),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Text("Released: ${movie.released}",
                          style: mainTextStyle()),
                      Text(movie.runtime, style: mainTextStyle()),
                      Text(movie.rated, style: mainTextStyle())
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
      onTap: () => {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    MovieListViewDetails(movieName: movie.title, movie: movie)))
      },
    );
  }

  TextStyle mainTextStyle() {
    return TextStyle(
      fontSize: 15.0,
      color: Colors.grey,
    );
  }

  Widget movieImage(String imageUrl) {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          image: DecorationImage(
            image: NetworkImage(imageUrl ??
                 'https://images-na.ssl-images-amazon.com/images/M/MV5BMTc0NzAxODAyMl5BMl5BanBnXkFtZTgwMDg0MzQ4MDE@._V1_SX1500_CR0,0,1500,999_AL_.jpg'),
             fit: BoxFit.cover
          )
           ),
    );
  }
}

// New route ( screen or page )
class MovieListViewDetails extends StatelessWidget {
  final String movieName;
  final Movie movie;

  const MovieListViewDetails({Key key, this.movieName, this.movie})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Movies"),
        backgroundColor: Colors.blueGrey.shade900,
      ),
      body: ListView(
        children: <Widget>[
          MovieDetailsThumbnail(thumbnail: movie.images[0]),
          MovieDetailsHeaderWithPoster(movie: movie),
          HorizontalLine(),
          MovieDetailsCast(movie: movie),
          HorizontalLine(),
          MovieDetailsExtraPosters(
            posters: movie.images,
          )
        ],
      ),
    );
  }
}





// class Screen1 extends StatelessWidget {


//   @override
//   Widget build(BuildContext context) {
//     print("Screen1");

//     return new Scaffold(
//       appBar: new AppBar(
//         title: new Text("Screen 1"),

//       ),
//       body: new Center(
//         child: new Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             new RaisedButton(onPressed:(){
//               Navigator.of(context).pushNamed('/screen2');
//             } ,child: new Text("Push to Screen 2"),),
//             new SizedBox(height: 10.0,),

//             new RaisedButton(
//               onPressed: (){
//                 print(Navigator.of(context).canPop().toString());
//               },
//               child: new Text("Can Pop"),),
//             new SizedBox(height: 10.0,),

//             new RaisedButton(
//               onPressed: (){
//                 Navigator.of(context).maybePop();
//               },
//               child: new Text("Maybe Pop"),),
//             new SizedBox(height: 10.0,),

//             new RaisedButton(
//               onPressed: (){
//                 Navigator.of(context).pop();
//               },
//               child: new Text("Pop"),)
//           ],
//         ),
//       ) ,
//     );
//   }
// }

// class Screen2 extends StatelessWidget {

//   @override
//   Widget build(BuildContext context) {

//     print("Screen2");


//     return new Scaffold(
//       appBar: new AppBar(
//         title: new Text("Screen 2"),
//         automaticallyImplyLeading: true,
//       ),
//       body: new Center(
//         child: new Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             new RaisedButton(onPressed: () {
//               Navigator.of(context).pushNamed('/screen3');
//             },
//               child: new Text("Push to Screen 3"),),
//             new SizedBox(height: 10.0,),


//             new RaisedButton(onPressed:(){
//               Navigator.of(context).pushNamed('/screen1');
//             } ,child: new Text("Push to Screen 1 instead of Pop"),),
//             new SizedBox(height: 10.0,),

//             new RaisedButton(onPressed: () {
//               String userName = "John Doe";
//               Navigator.push(
//                   context,
//                   new MaterialPageRoute(
//                       builder: (BuildContext context) =>
//                       new Screen5(userName)));
//             },
//               child: new Text("Push to Screen 5 using MaterialPageRoute"),),

//           ],
//         ),
//       ) ,
//     );

//   }
// }


// class Screen3 extends StatelessWidget {

//   @override
//   Widget build(BuildContext context) {

//     print("Screen3");

//     return new Scaffold(
//       appBar: new AppBar(
//         title: new Text("Screen 3"),

//       ),
//       body: new Center(
//         child: new Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             new RaisedButton(
//               onPressed: (){
//                 print(Navigator.of(context).canPop().toString());
//               },
//               child: new Text("Can Pop"),),
//             new SizedBox(height: 10.0,),


//             new RaisedButton(
//               onPressed: (){
//                 Navigator.of(context).maybePop();
//               },
//               child: new Text("Maybe Pop"),),
//             new SizedBox(height: 10.0,),


//             new RaisedButton(
//               onPressed: (){
//                 Navigator.of(context).pushReplacementNamed('/screen4');
//               },
//               child: new Text("Push Replacement Named"),),
//             new SizedBox(height: 10.0,),


//             new RaisedButton(
//               onPressed: (){
//                 Navigator.popAndPushNamed(context, '/screen4');
//               },
//               child: new Text("pop and Push Named"),),
//             new SizedBox(height: 10.0,),


//             new RaisedButton(
//               onPressed: (){
//                 Navigator.of(context).pushNamedAndRemoveUntil('/screen4', ModalRoute.withName('/screen1'));
//                // Navigator.of(context).pushNamedAndRemoveUntil('/screen4', (Route<dynamic> route) => false);
//               },
//               child: new Text("Push Named and Remove Until"),),
//             new SizedBox(height: 10.0,),


//             new RaisedButton(
//               onPressed: (){
//                 Navigator.of(context).pushAndRemoveUntil(new MaterialPageRoute( builder: (BuildContext context) => new Screen4()), ModalRoute.withName('/screen1'));
//               },
//               child: new Text("Push and Remove Until"),),
//             new SizedBox(height: 10.0,),





//             new RaisedButton(onPressed:(){
//               Navigator.of(context).pushNamed('/screen4');
//             } ,child: new Text("Push to Screen 4"),),
//             new SizedBox(height: 10.0,),


//             new RaisedButton(
//               onPressed: (){
//                 Navigator.push(context, new PageRouteBuilder(
//                     opaque: false,
//                     pageBuilder: (BuildContext context, _, __) {
//                       return new Scaffold(
//                         body: new Center(
//                           child: new Container(
//                               child: new Center(child: new Text('My PageRoute'))),
//                         ),
//                       );
//                     },
//                     transitionsBuilder: (___, Animation<double> animation, ____, Widget child) {
//                       return new FadeTransition(
//                         opacity: animation,
//                         child: new RotationTransition(
//                           turns: new Tween<double>(begin: 0.5, end: 1.0).animate(animation),
//                           child: child,
//                         ),
//                       );
//                     }
//                 ));
//               },
//               child: new Text("Page Route Builder"),),


//           ],
//         ),
//       ) ,
//     );

//   }
// }


// class Screen4 extends StatelessWidget {


//   @override
//   Widget build(BuildContext context) {
//     print("Screen4");

//     return new Scaffold( // 1
//       appBar: new AppBar( //2
//         title: new Text("Screen 4"),

//       ),
//       body: new Center( // 3
//         child: new Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             new RaisedButton(
//               onPressed: (){
//                 Navigator.popUntil(context, ModalRoute.withName('/screen2'));
//               },
//               child: new Text("popUntil"),),
//             new SizedBox(height: 10.0,),

//             new RaisedButton(onPressed: ()async{
//               String value = await Navigator.push(context, new MaterialPageRoute(
//                   builder: (BuildContext context) {
//                     return new Center(
//                       child: new GestureDetector(
//                           child: new Text('OK'),
//                           onTap: () { Navigator.pop(context, "Audio1"); }
//                       ),
//                     );
//                   }
//               )
//               );
//               print(value);

//             },
//               child: new Text("Return"),)

//           ],
//         ),
//       ) ,
//     );
//   }
// }


// class Screen5 extends StatelessWidget {

//   final String userName;
//   Screen5(this.userName);
//   @override
//   Widget build(BuildContext context) {

//     print("Screen5");


//     return new Scaffold(
//       appBar: new AppBar(
//         title: new Text("Screen 5"),
//         automaticallyImplyLeading: true,
//       ),
//       body: new Center(
//         child: new Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             new Text("Hi " + userName),
//           ],
//         ),
//       ) ,
//     );

//   }
// }

